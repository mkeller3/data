var map = new L.map('map', {
    center: new L.LatLng(34, -118),
    zoom: 9,
    attributionControl: true,
    zoomControl: true,
    minZoom: 2
});

var layer_id = 

L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}.png', {
    maxZoom: 18,
    attribution: 'ESRI',
}).addTo(map);

var wmsLayer = L.tileLayer.wms('http://localhost:8080/geoserver/ows?', {
    layers: layer_id,
    format: 'image/png',
    transparent: true,
    opacity: .5,
}).addTo(map);

$('#startOver').click(function () {
    polygonDrawer.disable();
    rectangleDrawer.disable();
    circleDrawer.disable();
    pointDrawer.disable();
    lineDrawer.disable();
    if (mapDrawing != undefined) {
        map.removeLayer(mapDrawing);
        mapDrawing = undefined;
        defaultDrawing = undefined;
    }
    mapDetails.attributes.forEach(function (element, index) {
        document.getElementById("counter" + index).innerHTML = 0;
    })

});

var rectangleDrawer = new L.Draw.Rectangle(map);
var polygonDrawer = new L.Draw.Polygon(map);
var circleDrawer = new L.Draw.Circle(map);
var pointDrawer = new L.Draw.Marker(map);
var lineDrawer = new L.Draw.Polyline(map);
$('#rectangle').click(function () {
    rectangleDrawer.enable();
    polygonDrawer.disable();
    circleDrawer.disable();
    pointDrawer.disable();
    lineDrawer.disable();
});

$('#polygon').click(function () {
    polygonDrawer.enable();
    rectangleDrawer.disable();
    circleDrawer.disable();
    pointDrawer.disable();
    lineDrawer.disable();
});

$('#circle').click(function () {
    polygonDrawer.disable();
    rectangleDrawer.disable();
    circleDrawer.enable();
    pointDrawer.disable();
    lineDrawer.disable();
});

$('#point').click(function () {
    polygonDrawer.disable();
    rectangleDrawer.disable();
    circleDrawer.disable();
    pointDrawer.enable();
    lineDrawer.disable();
});

$('#line').click(function () {
    polygonDrawer.disable();
    rectangleDrawer.disable();
    circleDrawer.disable();
    pointDrawer.disable();
    lineDrawer.enable();
});



var mapDetails = {
    attributes: [
        {
            'title': 'Total Claim Count',
            'task': 'total',
            'attribute': '',
            'unit': ''
        }, {
            'title': 'Severity 1',
            'task': 'sumInField',
            'attribute': 'severity2',
            'attributeValue': '1',
            'unit': ''
        }, {
            'title': 'Severity 2',
            'task': 'sumInField',
            'attribute': 'severity2',
            'attributeValue': '2',
            'unit': ''
        }, {
            'title': 'Severity 3',
            'task': 'sumInField',
            'attribute': 'severity2',
            'attributeValue': '3',
            'unit': ''
        }, {
            'title': 'Average Severity',
            'task': 'average',
            'attribute': 'severity2',
            'unit': ''
        }, {
            'title': 'Total Loss',
            'task': 'sum',
            'attribute': 'latitude',
            'unit': ''
        }
    ]
}

var mapDetails = {
    attributes: [
        {
            'title': 'Total Zip Codes',
            'task': 'total',
            'attribute': '',
            'unit': ''
        }, {
            'title': 'Average Policy Count',
            'task': 'average',
            'attribute': 'count',
            'unit': ''
        }, {
            'title': 'Total Policy Holders',
            'task': 'sum',
            'attribute': 'count',
            'unit': ''
        }
    ]
}

var uniqueAttributes = []



mapDetails.attributes.forEach(function (element, index) {
    if (uniqueAttributes.indexOf(element.attribute) === -1) {
        if (element.attribute != "") {
            uniqueAttributes.push(element.attribute);
        }
    }
    if (index == 0) {
        $('#panelContainer').append(`
            <div id="panel0" class="col test" style="display: block;">
                <div id="title0" class="titleCounter">${element.title}</div>
                <div id="counter0" class="counter" style="width: 204px; height: 40px;">0</div>
                <div id="units0" class="units">${element.unit}</div>
            </div>`
        )
    } else {
        $('#panelContainer').append(`
            <div id="panel${index}" class="col test" style="display: block;">
                <div id="title${index}" class="titleCounter">${element.title}</div>
                <div id="counter${index}" class="counter" style="width: 204px; height: 40px;">0</div>
                <div id="units${index}" class="units">${element.unit}</div>
            </div>`
        )
    }
})


function uniqueCounter(columnName, array) {
    attributes = []
    for (values in array) {
        attributes.push(array[values][columnName])

    }
    result = {};
    for (var i = 0; i < attributes.length; ++i) {
        if (!result[attributes[i]])
            result[attributes[i]] = 0;
        ++result[attributes[i]];
    }
    return result
}

function sumCounter(columnName, array) {
    attributes = []
    for (values in array) {
        if (!isNaN(parseFloat(array[values][columnName]))) {
            attributes.push(parseFloat(array[values][columnName]))
        }
    }
    var totalSum = attributes.reduce((partial_sum, a) => partial_sum + a);
    return totalSum
}

function averageCounter(columnName, array, totalFeatures) {
    attributes = []
    for (values in array) {
        if (!isNaN(parseFloat(array[values][columnName]))) {
            attributes.push(parseFloat(array[values][columnName]))
        }
    }
    var totalSum = attributes.reduce((partial_sum, a) => partial_sum + a);
    return totalSum / totalFeatures
}

function minimumValue(columnName, array) {
    attributes = []
    for (values in array) {
        if (!isNaN(parseFloat(array[values][columnName]))) {
            attributes.push(parseFloat(array[values][columnName]))
        }
    }
    return Math.min.apply(null, attributes)
}

function maximumValue(columnName, array) {
    attributes = []
    for (values in array) {
        if (!isNaN(parseFloat(array[values][columnName]))) {
            attributes.push(parseFloat(array[values][columnName]))
        }
    }
    return Math.max.apply(null, attributes)
}

var mapDrawing;

var defaultDrawing;

function bufferChange() {
    if (mapDrawing != undefined) {
        var feature = defaultDrawing;
        var circle = turf.buffer(feature, parseInt(document.getElementById("bufferValue").value), { units: 'miles', steps: 64 });
        var coords = circle.geometry.coordinates[0];
        polyStringParse = coords.toString().replace(/[^ \d,.-]/g, '');
        regExpPattern = /([^,]+[^,]),([^,]+[^,])/g;
        polyCQL = polyStringParse.replace(regExpPattern, '$1 $2');
        var url = "service=WFS&version=1.0.0&request=GetFeature&typeName=" + layer_id + "&outputFormat=application/json&SrsName=EPSG:4326&propertyName="+uniqueAttributes.toString()+"&cql_filter=INTERSECTS(geom, POLYGON((" + polyCQL + ")))";
        if (mapDrawing != undefined) {
            map.removeLayer(mapDrawing);
        }
        mapDrawing = L.geoJSON(circle).addTo(map);
        generateResults(url)

    }
}

map.on('draw:created', function (e) {
    var type = e.layerType;
    var layer = e.layer;

    if (type === 'polygon' || type === 'rectangle' || type === 'polyline') {
        var feature = e.layer.toGeoJSON();
        defaultDrawing = e.layer.toGeoJSON();
        var circle = turf.buffer(feature, parseInt(document.getElementById("bufferValue").value), { units: 'miles', steps: 4 });
        var coords = circle.geometry.coordinates[0];
        polyStringParse = coords.toString().replace(/[^ \d,.-]/g, '');
        regExpPattern = /([^,]+[^,]),([^,]+[^,])/g;
        polyCQL = polyStringParse.replace(regExpPattern, '$1 $2');
        var url = "service=WFS&version=1.0.0&request=GetFeature&typeName=" + layer_id + "&outputFormat=application/json&SrsName=EPSG:4326&propertyName="+uniqueAttributes.toString()+"&cql_filter=INTERSECTS(geom, POLYGON((" + polyCQL + ")))";
        if (mapDrawing != undefined) {
            map.removeLayer(mapDrawing);
        }
        mapDrawing = L.geoJSON(circle).addTo(map);
    }

    if (type === 'circle') {
        var radius = layer._mRadius;
        radius = radius / 1000;
        var center = [layer._latlng.lng, layer._latlng.lat];
        var options = { steps: 15, units: 'kilometers' };
        var circle = turf.circle(center, radius, options);
        defaultDrawing = circle;
        var circle = turf.buffer(circle, parseInt(document.getElementById("bufferValue").value), { units: 'miles' });
        var coords = circle.geometry.coordinates[0];
        polyStringParse = coords.toString().replace(/[^ \d,.-]/g, '');
        regExpPattern = /([^,]+[^,]),([^,]+[^,])/g;
        polyCQL = polyStringParse.replace(regExpPattern, '$1 $2');
        var url = "service=WFS&version=1.0.0&request=GetFeature&typeName=" + layer_id + "&outputFormat=application/json&SrsName=EPSG:4326&propertyName="+uniqueAttributes.toString()+"&cql_filter=INTERSECTS(geom, POLYGON((" + polyCQL + ")))";
        if (mapDrawing != undefined) {
            map.removeLayer(mapDrawing);
        }
        mapDrawing = L.geoJSON(circle).addTo(map);
    }

    if (type === 'marker') {
        if (document.getElementById("bufferValue").value == '0') {
            swal({
                icon: 'error',
                title: 'Oops...',
                text: 'You have buffer value of zero! For a marker you need a value greater than zero.',
            })
        } else {
            var feature = e.layer.toGeoJSON()
            var circle = turf.buffer(feature, parseInt(document.getElementById("bufferValue").value), { units: 'miles' });
            defaultDrawing = circle;
            var coords = circle.geometry.coordinates[0];
            polyStringParse = coords.toString().replace(/[^ \d,.-]/g, '');
            regExpPattern = /([^,]+[^,]),([^,]+[^,])/g;
            polyCQL = polyStringParse.replace(regExpPattern, '$1 $2');
            var url = "service=WFS&version=1.0.0&request=GetFeature&typeName=" + layer_id + "&outputFormat=application/json&SrsName=EPSG:4326&propertyName="+uniqueAttributes.toString()+"&cql_filter=INTERSECTS(geom, POLYGON((" + polyCQL + ")))";
            if (mapDrawing != undefined) {
                map.removeLayer(mapDrawing);
            }
            mapDrawing = L.geoJSON(circle).addTo(map);
        }
    }
    generateResults(url)
})

function generateResults(url) {
    $.ajax({
        url: 'http:/localhost:8080/geoserver/wfs?',
        dataType: 'json',
        type: 'POST',
        data: url,
        success: function (data) {
            mapValues = []
            data.features.forEach(element => {
                mapValues.push(element.properties)
            });
            mapDetails.attributes.forEach(function (element, index) {
                if (element.task == 'total') {
                    document.getElementById("counter" + index).innerHTML = data.totalFeatures.toLocaleString();
                }
                if (element.task == 'sum') {
                    var sumValueNumber = sumCounter(element.attribute, mapValues)
                    try {
                        document.getElementById("counter" + index).innerHTML = sumValueNumber.toLocaleString();
                    } catch{
                        document.getElementById("counter" + index).innerHTML = 0
                    }
                }
                if (element.task == 'sumInField') {
                    var count = uniqueCounter(element.attribute, mapValues);
                    try {
                        document.getElementById("counter" + index).innerHTML = count[element.attributeValue].toLocaleString();
                    } catch{
                        document.getElementById("counter" + index).innerHTML = 0
                    }
                }
                if (element.task == 'average') {
                    var average = averageCounter(element.attribute, mapValues, data.totalFeatures)
                    try {
                        document.getElementById("counter" + index).innerHTML = average.toFixed(4);
                    } catch{
                        document.getElementById("counter" + index).innerHTML = 0
                    }
                }
                if (element.task == 'minimum') {
                    var minimumValueNumber = minimumValue(element.attribute, mapValues)
                    try {
                        document.getElementById("counter" + index).innerHTML = minimumValueNumber.toFixed(4);
                    } catch{
                        document.getElementById("counter" + index).innerHTML = 'N/A'
                    }
                }
                if (element.task == 'maximum') {
                    var maximumValueNumber = maximumValue(element.attribute, mapValues)
                    try {
                        document.getElementById("counter" + index).innerHTML = maximumValueNumber.toFixed(4);
                    } catch{
                        document.getElementById("counter" + index).innerHTML = 'N/A'
                    }
                }
            })
        }
    })
}


